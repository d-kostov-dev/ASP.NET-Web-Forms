﻿using System.Web.UI;

namespace Application.Site.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}